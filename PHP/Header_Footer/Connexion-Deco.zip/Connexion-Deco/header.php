
<header>
        <nav>
            <h3 class="titre-header"><?php echo 'Utilisateur : <span class="rouge">'.$_SESSION["prenom_nom"].'</span>'; ?> </h3>
            <a href="session.php">Accueil</a>
            <a  href="deconnexion.php">Se déconnecter</a>
            
            
            
           
           
           
            <img class="logo headLogo" src="../../img\MenuizMan_logo.png" alt="logo">
        </nav>
</header>